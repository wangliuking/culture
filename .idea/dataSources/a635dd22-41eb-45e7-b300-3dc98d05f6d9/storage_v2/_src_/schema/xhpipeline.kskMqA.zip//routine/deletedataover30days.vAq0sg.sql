create procedure deleteDataOver30days()
  BEGIN

DELETE from xhpipeline.cat_protect_off_elec_history WHERE DATE_FORMAT(DATE_SUB(NOW(),INTERVAL 30 DAY),"%Y-%m-%d %H:00:00")> DATE_FORMAT(time,"%Y-%m-%d %H:00:00");

END;

