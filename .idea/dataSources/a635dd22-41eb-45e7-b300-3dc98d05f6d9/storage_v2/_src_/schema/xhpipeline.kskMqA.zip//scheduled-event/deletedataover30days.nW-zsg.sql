create definer = root@`%` event deleteDataOver30days
  on schedule
    every '1' HOUR
      starts '2019-10-25 14:45:00'
  enable
do
  call deleteDataOver30days;

